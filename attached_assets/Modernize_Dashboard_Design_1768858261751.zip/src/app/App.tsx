import { useState } from 'react';
import { 
  Bell, 
  Menu, 
  Calendar, 
  Clock, 
  Users, 
  AlertCircle,
  CalendarCheck,
  PlayCircle,
  CalendarDays,
  FileText,
  BookOpen,
  MessageSquare,
  Briefcase,
  TrendingUp,
  ArrowRight
} from 'lucide-react';
import { Badge } from '@/app/components/ui/badge';
import { Button } from '@/app/components/ui/button';
import { Card } from '@/app/components/ui/card';

export default function App() {
  const [notifications] = useState(2);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
      {/* Mobile Status Bar */}
      <div className="bg-white border-b border-slate-200">
        <div className="px-4 py-3 flex items-center justify-between">
          <span className="text-sm font-medium">4:14</span>
          <div className="flex items-center gap-1">
            <div className="flex gap-0.5">
              <div className="w-0.5 h-3 bg-slate-900 rounded"></div>
              <div className="w-0.5 h-3 bg-slate-900 rounded"></div>
              <div className="w-0.5 h-3 bg-slate-900 rounded"></div>
              <div className="w-0.5 h-3 bg-slate-400 rounded"></div>
            </div>
            <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor">
              <path d="M5 12.55a11 11 0 0 1 14.08 0" strokeWidth="2" strokeLinecap="round"/>
              <path d="M1.42 9a16 16 0 0 1 21.16 0" strokeWidth="2" strokeLinecap="round"/>
            </svg>
            <div className="w-6 h-3 border-2 border-slate-900 rounded-sm relative">
              <div className="absolute right-0 top-1/2 -translate-y-1/2 w-0.5 h-2 bg-slate-900"></div>
            </div>
          </div>
        </div>
      </div>

      {/* Header */}
      <div className="bg-white border-b border-slate-200 sticky top-0 z-10 shadow-sm">
        <div className="px-4 py-4 flex items-center justify-between">
          <div>
            <h1 className="text-lg font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
              Demo Healthcare Staffing
            </h1>
          </div>
          <div className="flex items-center gap-3">
            <button className="relative">
              <Bell className="w-5 h-5 text-slate-600" />
              {notifications > 0 && (
                <Badge className="absolute -top-1 -right-1 h-4 w-4 flex items-center justify-center p-0 bg-red-500 text-white text-xs">
                  {notifications}
                </Badge>
              )}
            </button>
            <button>
              <Menu className="w-5 h-5 text-slate-600" />
            </button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="px-4 pb-24 pt-6">
        {/* Welcome Section */}
        <div className="mb-6">
          <h2 className="text-2xl font-bold text-slate-900 mb-1">
            Welcome back, Demo
          </h2>
          <p className="text-slate-600">
            Manage your shifts, schedule, and time tracking
          </p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 gap-3 mb-6">
          {/* Today's Shifts */}
          <Card className="p-4 bg-gradient-to-br from-blue-500 to-blue-600 border-0 shadow-lg shadow-blue-500/30 hover:shadow-xl hover:shadow-blue-500/40 transition-all duration-300">
            <div className="flex flex-col h-full">
              <div className="flex items-start justify-between mb-3">
                <div className="p-2 bg-white/20 rounded-lg backdrop-blur">
                  <Calendar className="w-5 h-5 text-white" />
                </div>
              </div>
              <div>
                <div className="text-3xl font-bold text-white mb-1">2</div>
                <div className="text-blue-100 text-sm">Today's Shifts</div>
              </div>
            </div>
          </Card>

          {/* Upcoming */}
          <Card className="p-4 bg-gradient-to-br from-emerald-500 to-teal-600 border-0 shadow-lg shadow-emerald-500/30 hover:shadow-xl hover:shadow-emerald-500/40 transition-all duration-300">
            <div className="flex flex-col h-full">
              <div className="flex items-start justify-between mb-3">
                <div className="p-2 bg-white/20 rounded-lg backdrop-blur">
                  <Clock className="w-5 h-5 text-white" />
                </div>
              </div>
              <div>
                <div className="text-3xl font-bold text-white mb-1">5</div>
                <div className="text-emerald-100 text-sm">Upcoming</div>
              </div>
            </div>
          </Card>

          {/* Status */}
          <Card className="p-4 bg-gradient-to-br from-amber-500 to-orange-600 border-0 shadow-lg shadow-amber-500/30 hover:shadow-xl hover:shadow-amber-500/40 transition-all duration-300">
            <div className="flex flex-col h-full">
              <div className="flex items-start justify-between mb-3">
                <div className="p-2 bg-white/20 rounded-lg backdrop-blur">
                  <AlertCircle className="w-5 h-5 text-white" />
                </div>
              </div>
              <div>
                <div className="text-sm font-semibold text-white mb-1">Clocked Out</div>
                <div className="text-amber-100 text-xs">Status</div>
              </div>
            </div>
          </Card>

          {/* This Week */}
          <Card className="p-4 bg-gradient-to-br from-purple-500 to-indigo-600 border-0 shadow-lg shadow-purple-500/30 hover:shadow-xl hover:shadow-purple-500/40 transition-all duration-300">
            <div className="flex flex-col h-full">
              <div className="flex items-start justify-between mb-3">
                <div className="p-2 bg-white/20 rounded-lg backdrop-blur">
                  <Users className="w-5 h-5 text-white" />
                </div>
              </div>
              <div>
                <div className="text-3xl font-bold text-white mb-1">12</div>
                <div className="text-purple-100 text-sm">This Week</div>
              </div>
            </div>
          </Card>
        </div>

        {/* Quick Actions */}
        <Card className="p-5 mb-6 bg-white border-slate-200 shadow-sm">
          <h3 className="text-lg font-bold text-slate-900 mb-4">Quick Actions</h3>
          
          <div className="grid grid-cols-2 gap-3 mb-3">
            <Button className="h-auto py-4 px-4 bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white shadow-md hover:shadow-lg transition-all duration-300 flex flex-col items-center gap-2">
              <CalendarCheck className="w-5 h-5" />
              <span className="text-sm font-semibold">Browse Shifts</span>
            </Button>
            
            <Button className="h-auto py-4 px-4 bg-gradient-to-r from-cyan-500 to-cyan-600 hover:from-cyan-600 hover:to-cyan-700 text-white shadow-md hover:shadow-lg transition-all duration-300 flex flex-col items-center gap-2">
              <PlayCircle className="w-5 h-5" />
              <span className="text-sm font-semibold">Clock In</span>
            </Button>
          </div>

          <div className="grid grid-cols-2 gap-3 mb-3">
            <Button 
              variant="outline" 
              className="h-auto py-4 px-4 border-2 border-slate-200 hover:border-blue-300 hover:bg-blue-50 transition-all duration-300 flex flex-col items-center gap-2"
            >
              <CalendarDays className="w-5 h-5 text-slate-700" />
              <span className="text-sm font-semibold text-slate-700">My Schedule</span>
            </Button>
            
            <Button 
              variant="outline" 
              className="h-auto py-4 px-4 border-2 border-slate-200 hover:border-blue-300 hover:bg-blue-50 transition-all duration-300 flex flex-col items-center gap-2"
            >
              <FileText className="w-5 h-5 text-slate-700" />
              <span className="text-sm font-semibold text-slate-700">Timesheets</span>
            </Button>
          </div>

          <Button 
            variant="outline" 
            className="w-full h-auto py-3 px-4 border-2 border-purple-200 hover:border-purple-400 hover:bg-purple-50 transition-all duration-300"
          >
            <BookOpen className="w-4 h-4 text-purple-600 mr-2" />
            <span className="text-sm font-semibold text-purple-600">Download Employee Guide</span>
          </Button>
        </Card>

        {/* Today's Schedule */}
        <Card className="p-5 mb-6 bg-white border-slate-200 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <div className="p-2 bg-blue-100 rounded-lg">
                <Calendar className="w-4 h-4 text-blue-600" />
              </div>
              <h3 className="text-lg font-bold text-slate-900">Today's Schedule</h3>
            </div>
          </div>
          
          <div className="flex flex-col items-center justify-center py-8">
            <div className="w-20 h-20 bg-gradient-to-br from-slate-100 to-slate-200 rounded-full flex items-center justify-center mb-4">
              <Calendar className="w-10 h-10 text-slate-400" />
            </div>
            <p className="text-slate-500 mb-4 text-center">No shifts scheduled for today</p>
            <Button 
              variant="outline"
              className="border-2 border-blue-200 hover:border-blue-400 hover:bg-blue-50 text-blue-600 font-semibold"
            >
              Browse Available Shifts
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </div>
        </Card>

        {/* Upcoming Shifts */}
        <Card className="p-5 bg-white border-slate-200 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <div className="p-2 bg-emerald-100 rounded-lg">
                <Clock className="w-4 h-4 text-emerald-600" />
              </div>
              <h3 className="text-lg font-bold text-slate-900">Upcoming Shifts</h3>
            </div>
            <Button variant="ghost" size="sm" className="text-blue-600 font-semibold hover:text-blue-700 hover:bg-blue-50">
              View All
            </Button>
          </div>
          
          <div className="flex flex-col items-center justify-center py-8">
            <div className="w-20 h-20 bg-gradient-to-br from-slate-100 to-slate-200 rounded-full flex items-center justify-center mb-4">
              <Clock className="w-10 h-10 text-slate-400" />
            </div>
            <p className="text-slate-500 mb-4 text-center">No upcoming shifts scheduled</p>
            <Button 
              variant="outline"
              className="border-2 border-emerald-200 hover:border-emerald-400 hover:bg-emerald-50 text-emerald-600 font-semibold"
            >
              Find Shifts to Apply For
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </div>
        </Card>
      </div>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 shadow-lg">
        <div className="grid grid-cols-5 gap-1 px-2 py-2">
          <button className="flex flex-col items-center py-2 px-3 rounded-lg hover:bg-slate-50 transition-colors">
            <PlayCircle className="w-5 h-5 text-slate-400 mb-1" />
            <span className="text-xs text-slate-600">Clock In/Out</span>
          </button>
          
          <button className="flex flex-col items-center py-2 px-3 rounded-lg bg-blue-50 transition-colors">
            <Briefcase className="w-5 h-5 text-blue-600 mb-1" />
            <span className="text-xs text-blue-600 font-semibold">Available Shifts</span>
          </button>
          
          <button className="flex flex-col items-center py-2 px-3 rounded-lg hover:bg-slate-50 transition-colors">
            <CalendarDays className="w-5 h-5 text-slate-400 mb-1" />
            <span className="text-xs text-slate-600">My Schedule</span>
          </button>
          
          <button className="flex flex-col items-center py-2 px-3 rounded-lg hover:bg-slate-50 transition-colors">
            <TrendingUp className="w-5 h-5 text-slate-400 mb-1" />
            <span className="text-xs text-slate-600">Timesheets</span>
          </button>
          
          <button className="flex flex-col items-center py-2 px-3 rounded-lg hover:bg-slate-50 transition-colors">
            <MessageSquare className="w-5 h-5 text-slate-400 mb-1" />
            <span className="text-xs text-slate-600">Messages</span>
          </button>
        </div>
      </div>
    </div>
  );
}
