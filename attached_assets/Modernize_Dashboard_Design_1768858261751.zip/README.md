
  # Modernize Dashboard Design

  This is a code bundle for Modernize Dashboard Design. The original project is available at https://www.figma.com/design/VR2MSbGIt8FYTuKelJoXYq/Modernize-Dashboard-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  