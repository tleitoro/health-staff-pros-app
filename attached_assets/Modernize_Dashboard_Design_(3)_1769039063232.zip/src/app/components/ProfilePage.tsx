import { useState } from 'react';
import { 
  ArrowLeft,
  Camera,
  User,
  Mail,
  Phone,
  MapPin,
  FileText,
  Calendar,
  IdCard,
  Clock,
  Menu,
  LayoutDashboard,
  Settings,
  LogOut,
  UserCircle
} from 'lucide-react';
import { Badge } from '@/app/components/ui/badge';
import { Button } from '@/app/components/ui/button';
import { Card } from '@/app/components/ui/card';
import { Input } from '@/app/components/ui/input';
import { Label } from '@/app/components/ui/label';
import { Textarea } from '@/app/components/ui/textarea';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/app/components/ui/dropdown-menu';

interface ProfilePageProps {
  onBack: () => void;
}

export function ProfilePage({ onBack }: ProfilePageProps) {
  const [formData, setFormData] = useState({
    firstName: 'Demo',
    lastName: 'Employee',
    email: 'employee-demo@healthstaffpros.com',
    phone: '717-220-5666',
    address: '',
    bio: ''
  });

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 pb-24">
      {/* Mobile Status Bar */}
      <div className="bg-slate-900 text-white">
        <div className="px-4 py-3 flex items-center justify-between">
          <span className="text-sm font-medium">5:28</span>
          <div className="flex items-center gap-1">
            <div className="flex gap-0.5">
              <div className="w-0.5 h-3 bg-white rounded"></div>
              <div className="w-0.5 h-3 bg-white rounded"></div>
              <div className="w-0.5 h-3 bg-white rounded"></div>
              <div className="w-0.5 h-3 bg-white/40 rounded"></div>
            </div>
            <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor">
              <path d="M5 12.55a11 11 0 0 1 14.08 0" strokeWidth="2" strokeLinecap="round"/>
              <path d="M1.42 9a16 16 0 0 1 21.16 0" strokeWidth="2" strokeLinecap="round"/>
            </svg>
            <div className="w-6 h-3 border-2 border-white rounded-sm relative">
              <div className="absolute right-0 top-1/2 -translate-y-1/2 w-0.5 h-2 bg-white"></div>
            </div>
          </div>
        </div>
      </div>

      {/* Top Navigation Bar */}
      <div className="bg-slate-900 text-white px-4 py-4 flex items-center justify-between">
        <button 
          onClick={onBack}
          className="p-2 hover:bg-slate-800 rounded-full transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-white rounded flex items-center justify-center">
            <svg className="w-5 h-5 text-blue-600" viewBox="0 0 24 24" fill="currentColor">
              <path d="M12 2L2 7v10c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V7l-10-5z"/>
              <path d="M10 17l-3-3 1.41-1.41L10 14.17l5.59-5.59L17 10l-7 7z" fill="white"/>
            </svg>
          </div>
          <span className="font-bold">Health Staff Pros</span>
        </div>
        <div className="flex items-center gap-2">
          <button className="p-2 hover:bg-slate-800 rounded-lg transition-colors">
            <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <rect x="3" y="3" width="7" height="7" rx="1"/>
              <rect x="14" y="3" width="7" height="7" rx="1"/>
              <rect x="14" y="14" width="7" height="7" rx="1"/>
              <rect x="3" y="14" width="7" height="7" rx="1"/>
            </svg>
          </button>
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button className="p-2 hover:bg-slate-800 rounded-lg transition-colors">
                <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <circle cx="12" cy="12" r="3"/>
                  <path d="M12 1v6m0 6v6M4.22 4.22l4.24 4.24m5.08 5.08l4.24 4.24M1 12h6m6 0h6M4.22 19.78l4.24-4.24m5.08-5.08l4.24-4.24"/>
                </svg>
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent 
              align="end" 
              className="w-64 bg-white border-slate-200 shadow-xl rounded-xl p-2"
            >
              {/* User Info Header */}
              <div className="px-3 py-3 mb-2">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center text-white font-bold text-lg shadow-md">
                    DE
                  </div>
                  <div className="flex-1">
                    <p className="font-bold text-slate-900">Demo Employee</p>
                    <p className="text-sm text-slate-500">Employee</p>
                  </div>
                </div>
              </div>

              <DropdownMenuSeparator className="bg-slate-200" />

              {/* Menu Items */}
              <DropdownMenuItem 
                className="flex items-center gap-3 px-3 py-2.5 rounded-lg cursor-pointer hover:bg-blue-50 transition-colors"
              >
                <div className="w-8 h-8 rounded-lg bg-blue-100 flex items-center justify-center">
                  <UserCircle className="w-4 h-4 text-blue-600" />
                </div>
                <span className="font-medium text-slate-700">Profile</span>
              </DropdownMenuItem>

              <DropdownMenuItem 
                onClick={onBack}
                className="flex items-center gap-3 px-3 py-2.5 rounded-lg cursor-pointer hover:bg-emerald-50 transition-colors"
              >
                <div className="w-8 h-8 rounded-lg bg-emerald-100 flex items-center justify-center">
                  <LayoutDashboard className="w-4 h-4 text-emerald-600" />
                </div>
                <span className="font-medium text-slate-700">Dashboard</span>
              </DropdownMenuItem>

              <DropdownMenuItem 
                className="flex items-center gap-3 px-3 py-2.5 rounded-lg cursor-pointer hover:bg-purple-50 transition-colors"
              >
                <div className="w-8 h-8 rounded-lg bg-purple-100 flex items-center justify-center">
                  <Settings className="w-4 h-4 text-purple-600" />
                </div>
                <span className="font-medium text-slate-700">Settings</span>
              </DropdownMenuItem>

              <DropdownMenuSeparator className="bg-slate-200 my-2" />

              <DropdownMenuItem 
                variant="destructive"
                className="flex items-center gap-3 px-3 py-2.5 rounded-lg cursor-pointer hover:bg-red-50 transition-colors"
              >
                <div className="w-8 h-8 rounded-lg bg-red-100 flex items-center justify-center">
                  <LogOut className="w-4 h-4 text-red-600" />
                </div>
                <span className="font-medium text-red-600">Sign Out</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      {/* Header */}
      <div className="bg-white border-b border-slate-200 px-4 py-4">
        <h1 className="text-lg font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
          Demo Healthcare Staffing
        </h1>
      </div>

      {/* Back to Dashboard Link */}
      <div className="px-4 py-3">
        <button 
          onClick={onBack}
          className="flex items-center gap-2 text-slate-600 hover:text-blue-600 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span className="text-sm font-medium">Back to Dashboard</span>
        </button>
      </div>

      {/* Profile Header Card */}
      <div className="px-4 mb-6">
        <Card className="bg-white border-slate-200 shadow-lg overflow-hidden">
          {/* Gradient Background */}
          <div className="h-24 bg-gradient-to-r from-blue-500 via-indigo-500 to-purple-500"></div>
          
          {/* Profile Content */}
          <div className="px-6 pb-6 -mt-12 relative">
            {/* Avatar */}
            <div className="relative inline-block mb-4">
              <div className="w-24 h-24 rounded-full bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center text-white text-3xl font-bold border-4 border-white shadow-lg">
                DE
              </div>
              <button className="absolute bottom-0 right-0 w-8 h-8 bg-white rounded-full border-2 border-slate-200 flex items-center justify-center shadow-md hover:bg-slate-50 transition-colors">
                <Camera className="w-4 h-4 text-slate-600" />
              </button>
            </div>

            {/* Name and Info */}
            <div className="mb-4">
              <h2 className="text-2xl font-bold text-slate-900 mb-2">Demo Employee</h2>
              <Badge className="bg-emerald-100 text-emerald-700 border-emerald-200 hover:bg-emerald-100 mb-3">
                Employee
              </Badge>
              
              <div className="flex flex-col gap-2">
                <div className="flex items-center gap-2 text-slate-600">
                  <Mail className="w-4 h-4" />
                  <span className="text-sm">employee-demo@healthstaffpros.com</span>
                </div>
                <div className="flex items-center gap-2 text-emerald-600">
                  <Calendar className="w-4 h-4" />
                  <span className="text-sm font-medium">Joined 1/17/2026</span>
                </div>
              </div>
            </div>
          </div>
        </Card>
      </div>

      {/* Personal Information Form */}
      <div className="px-4 mb-6">
        <Card className="p-6 bg-white border-slate-200 shadow-sm">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-2 bg-blue-100 rounded-lg">
              <User className="w-5 h-5 text-blue-600" />
            </div>
            <h3 className="text-lg font-bold text-slate-900">Personal Information</h3>
          </div>

          <div className="space-y-4">
            {/* First Name */}
            <div>
              <Label className="flex items-center gap-2 mb-2 text-blue-600 font-semibold">
                <span className="w-1.5 h-1.5 bg-blue-600 rounded-full"></span>
                First Name
              </Label>
              <Input
                value={formData.firstName}
                onChange={(e) => handleInputChange('firstName', e.target.value)}
                className="border-2 border-slate-200 focus:border-blue-400 focus:ring-2 focus:ring-blue-100 bg-white"
              />
            </div>

            {/* Last Name */}
            <div>
              <Label className="flex items-center gap-2 mb-2 text-purple-600 font-semibold">
                <span className="w-1.5 h-1.5 bg-purple-600 rounded-full"></span>
                Last Name
              </Label>
              <Input
                value={formData.lastName}
                onChange={(e) => handleInputChange('lastName', e.target.value)}
                className="border-2 border-slate-200 focus:border-purple-400 focus:ring-2 focus:ring-purple-100 bg-white"
              />
            </div>

            {/* Email Address */}
            <div>
              <Label className="flex items-center gap-2 mb-2 text-emerald-600 font-semibold">
                <span className="w-1.5 h-1.5 bg-emerald-600 rounded-full"></span>
                Email Address
              </Label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <Input
                  type="email"
                  value={formData.email}
                  onChange={(e) => handleInputChange('email', e.target.value)}
                  className="pl-10 border-2 border-slate-200 focus:border-emerald-400 focus:ring-2 focus:ring-emerald-100 bg-white"
                />
              </div>
            </div>

            {/* Phone Number */}
            <div>
              <Label className="flex items-center gap-2 mb-2 text-indigo-600 font-semibold">
                <span className="w-1.5 h-1.5 bg-indigo-600 rounded-full"></span>
                Phone Number
              </Label>
              <div className="relative">
                <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <Input
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => handleInputChange('phone', e.target.value)}
                  className="pl-10 border-2 border-slate-200 focus:border-indigo-400 focus:ring-2 focus:ring-indigo-100 bg-white"
                />
              </div>
            </div>

            {/* Address */}
            <div>
              <Label className="flex items-center gap-2 mb-2 text-orange-600 font-semibold">
                <span className="w-1.5 h-1.5 bg-orange-600 rounded-full"></span>
                Address
              </Label>
              <div className="relative">
                <MapPin className="absolute left-3 top-3 w-4 h-4 text-slate-400" />
                <Input
                  value={formData.address}
                  onChange={(e) => handleInputChange('address', e.target.value)}
                  placeholder="Enter your address..."
                  className="pl-10 border-2 border-slate-200 focus:border-orange-400 focus:ring-2 focus:ring-orange-100 bg-white"
                />
              </div>
            </div>

            {/* Bio */}
            <div>
              <Label className="flex items-center gap-2 mb-2 text-pink-600 font-semibold">
                <span className="w-1.5 h-1.5 bg-pink-600 rounded-full"></span>
                Bio
              </Label>
              <Textarea
                value={formData.bio}
                onChange={(e) => handleInputChange('bio', e.target.value)}
                placeholder="Tell us about yourself..."
                className="min-h-[120px] border-2 border-slate-200 focus:border-pink-400 focus:ring-2 focus:ring-pink-100 bg-white resize-none"
              />
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3 mt-6">
            <Button
              variant="outline"
              className="flex-1 border-2 border-slate-200 hover:border-slate-300 hover:bg-slate-50"
            >
              Cancel
            </Button>
            <Button className="flex-1 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white shadow-md hover:shadow-lg transition-all duration-300">
              Save Changes
            </Button>
          </div>
        </Card>
      </div>

      {/* Professional Information */}
      <div className="px-4 mb-6">
        <Card className="p-6 bg-white border-slate-200 shadow-sm">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-2 bg-emerald-100 rounded-lg">
              <FileText className="w-5 h-5 text-emerald-600" />
            </div>
            <h3 className="text-lg font-bold text-slate-900">Professional Information</h3>
          </div>

          {/* Empty State */}
          <div className="flex flex-col items-center justify-center py-8">
            <div className="w-20 h-20 bg-gradient-to-br from-slate-100 to-slate-200 rounded-full flex items-center justify-center mb-4">
              <FileText className="w-10 h-10 text-slate-400" />
            </div>
            <h4 className="text-lg font-bold text-slate-900 mb-2">No Professional Information</h4>
            <p className="text-slate-500 text-center mb-4 text-sm">
              Complete your application to see professional details here.
            </p>
            <Button className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white shadow-md hover:shadow-lg transition-all duration-300">
              Complete Application
            </Button>
          </div>
        </Card>
      </div>

      {/* Account Details */}
      <div className="px-4 mb-6">
        <Card className="p-6 bg-white border-slate-200 shadow-sm">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-2 bg-purple-100 rounded-lg">
              <IdCard className="w-5 h-5 text-purple-600" />
            </div>
            <h3 className="text-lg font-bold text-slate-900">Account Details</h3>
          </div>

          <div className="space-y-4">
            {/* Account Type */}
            <div>
              <Label className="flex items-center gap-2 mb-2 text-blue-600 font-semibold">
                <span className="w-1.5 h-1.5 bg-blue-600 rounded-full"></span>
                Account Type
              </Label>
              <div className="p-4 bg-blue-50 border-2 border-blue-200 rounded-lg">
                <span className="text-blue-700 font-semibold">Employee</span>
              </div>
            </div>

            {/* Member Since */}
            <div>
              <Label className="flex items-center gap-2 mb-2 text-emerald-600 font-semibold">
                <span className="w-1.5 h-1.5 bg-emerald-600 rounded-full"></span>
                Member Since
              </Label>
              <div className="p-4 bg-emerald-50 border-2 border-emerald-200 rounded-lg flex items-center gap-2">
                <Calendar className="w-4 h-4 text-emerald-600" />
                <span className="text-emerald-700 font-semibold">January 17, 2026</span>
              </div>
            </div>

            {/* User ID */}
            <div>
              <Label className="flex items-center gap-2 mb-2 text-cyan-600 font-semibold">
                <span className="w-1.5 h-1.5 bg-cyan-600 rounded-full"></span>
                User ID
              </Label>
              <div className="p-4 bg-cyan-50 border-2 border-cyan-200 rounded-lg flex items-center gap-2">
                <IdCard className="w-4 h-4 text-cyan-600" />
                <span className="text-cyan-700 font-mono">demo-employee-001</span>
              </div>
            </div>

            {/* Last Updated */}
            <div>
              <Label className="flex items-center gap-2 mb-2 text-amber-600 font-semibold">
                <span className="w-1.5 h-1.5 bg-amber-600 rounded-full"></span>
                Last Updated
              </Label>
              <div className="p-4 bg-amber-50 border-2 border-amber-200 rounded-lg flex items-center gap-2">
                <Clock className="w-4 h-4 text-amber-600" />
                <span className="text-amber-700 font-semibold">January 17, 2026</span>
              </div>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}