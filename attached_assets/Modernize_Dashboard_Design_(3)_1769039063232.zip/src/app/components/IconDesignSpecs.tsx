import { Card } from '@/app/components/ui/card';
import { Copy } from 'lucide-react';

export function IconDesignSpecs() {
  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 p-8">
      <div className="max-w-5xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-slate-900 mb-3">
            Healthcare Team Icon - Design Specifications
          </h1>
          <p className="text-lg text-slate-600">
            Complete design documentation for implementation
          </p>
        </div>

        {/* Icon Preview */}
        <Card className="p-8 mb-8 bg-white border-slate-200 shadow-lg">
          <h2 className="text-2xl font-bold text-slate-900 mb-6 text-center">Icon Preview</h2>
          <div className="flex justify-center mb-6">
            <svg
              width="300"
              height="300"
              viewBox="0 0 1024 1024"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="drop-shadow-2xl"
            >
              {/* Background with gradient */}
              <rect width="1024" height="1024" rx="226" fill="url(#grad1)" />
              
              <defs>
                <linearGradient id="grad1" x1="0" y1="0" x2="1024" y2="1024" gradientUnits="userSpaceOnUse">
                  <stop offset="0%" stopColor="#3B82F6" />
                  <stop offset="50%" stopColor="#6366F1" />
                  <stop offset="100%" stopColor="#8B5CF6" />
                </linearGradient>
              </defs>

              {/* Decorative circles */}
              <circle cx="850" cy="200" r="180" fill="white" fillOpacity="0.1" />
              <circle cx="180" cy="850" r="150" fill="white" fillOpacity="0.1" />

              {/* Three healthcare workers - silhouettes */}
              <g transform="translate(512, 600)">
                {/* Left worker - Nurse */}
                <g transform="translate(-200, 0)">
                  {/* Head */}
                  <circle cx="0" cy="-100" r="50" fill="white" />
                  {/* Body */}
                  <path d="M -60 -50 L -60 100 L 60 100 L 60 -50 Z" fill="white" fillOpacity="0.95" />
                  {/* Cross on chest */}
                  <rect x="-15" y="-20" width="30" height="60" rx="5" fill="#3B82F6" />
                  <rect x="-30" y="-5" width="60" height="30" rx="5" fill="#6366F1" />
                </g>

                {/* Center worker - Doctor (taller) */}
                <g transform="translate(0, -40)">
                  {/* Head */}
                  <circle cx="0" cy="-110" r="55" fill="white" />
                  {/* Body */}
                  <path d="M -70 -55 L -70 140 L 70 140 L 70 -55 Z" fill="white" />
                  {/* Stethoscope */}
                  <circle cx="0" cy="40" r="25" fill="#10B981" opacity="0.9" />
                  <path d="M 0 15 Q -20 -20 -25 -55" stroke="#10B981" strokeWidth="12" fill="none" strokeLinecap="round" />
                  <circle cx="-25" cy="-55" r="8" fill="#10B981" />
                </g>

                {/* Right worker - Healthcare staff */}
                <g transform="translate(200, 0)">
                  {/* Head */}
                  <circle cx="0" cy="-100" r="50" fill="white" />
                  {/* Body */}
                  <path d="M -60 -50 L -60 100 L 60 100 L 60 -50 Z" fill="white" fillOpacity="0.95" />
                  {/* Clipboard */}
                  <rect x="-20" y="-10" width="40" height="60" rx="5" fill="#F59E0B" opacity="0.9" />
                  <rect x="-15" y="-5" width="30" height="10" rx="2" fill="#FBBF24" />
                </g>
              </g>

              {/* Shine effect */}
              <ellipse cx="512" cy="280" rx="350" ry="180" fill="white" fillOpacity="0.12" />
            </svg>
          </div>
        </Card>

        {/* Canvas Size & Format */}
        <Card className="p-6 mb-6 bg-white border-slate-200 shadow-sm">
          <h2 className="text-xl font-bold text-slate-900 mb-4">📐 Canvas Size & Format</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-slate-50 p-4 rounded-lg">
              <p className="text-sm text-slate-600 mb-1">Canvas Dimensions</p>
              <p className="text-2xl font-bold text-slate-900">1024 × 1024px</p>
              <p className="text-xs text-slate-500 mt-1">Square format (1:1 aspect ratio)</p>
            </div>
            <div className="bg-slate-50 p-4 rounded-lg">
              <p className="text-sm text-slate-600 mb-1">Corner Radius</p>
              <p className="text-2xl font-bold text-slate-900">226px</p>
              <p className="text-xs text-slate-500 mt-1">22% of canvas size (iOS standard)</p>
            </div>
            <div className="bg-slate-50 p-4 rounded-lg">
              <p className="text-sm text-slate-600 mb-1">Recommended Format</p>
              <p className="text-2xl font-bold text-slate-900">PNG</p>
              <p className="text-xs text-slate-500 mt-1">24-bit RGB with transparency</p>
            </div>
            <div className="bg-slate-50 p-4 rounded-lg">
              <p className="text-sm text-slate-600 mb-1">Color Space</p>
              <p className="text-2xl font-bold text-slate-900">sRGB</p>
              <p className="text-xs text-slate-500 mt-1">Display P3 for iOS is optional</p>
            </div>
          </div>
        </Card>

        {/* Background Gradient */}
        <Card className="p-6 mb-6 bg-white border-slate-200 shadow-sm">
          <h2 className="text-xl font-bold text-slate-900 mb-4">🎨 Background Gradient</h2>
          
          <div className="mb-4">
            <div className="h-32 rounded-lg mb-3" style={{
              background: 'linear-gradient(135deg, #3B82F6 0%, #6366F1 50%, #8B5CF6 100%)'
            }}></div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="border-2 border-slate-200 p-4 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <p className="text-sm font-semibold text-slate-700">Start Color (0%)</p>
                <button 
                  onClick={() => copyToClipboard('#3B82F6')}
                  className="p-1 hover:bg-slate-100 rounded"
                >
                  <Copy className="w-4 h-4 text-slate-500" />
                </button>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-lg border-2 border-slate-200" style={{ backgroundColor: '#3B82F6' }}></div>
                <div>
                  <p className="font-mono text-sm font-bold text-slate-900">#3B82F6</p>
                  <p className="font-mono text-xs text-slate-600">RGB(59, 130, 246)</p>
                </div>
              </div>
            </div>

            <div className="border-2 border-slate-200 p-4 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <p className="text-sm font-semibold text-slate-700">Middle Color (50%)</p>
                <button 
                  onClick={() => copyToClipboard('#6366F1')}
                  className="p-1 hover:bg-slate-100 rounded"
                >
                  <Copy className="w-4 h-4 text-slate-500" />
                </button>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-lg border-2 border-slate-200" style={{ backgroundColor: '#6366F1' }}></div>
                <div>
                  <p className="font-mono text-sm font-bold text-slate-900">#6366F1</p>
                  <p className="font-mono text-xs text-slate-600">RGB(99, 102, 241)</p>
                </div>
              </div>
            </div>

            <div className="border-2 border-slate-200 p-4 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <p className="text-sm font-semibold text-slate-700">End Color (100%)</p>
                <button 
                  onClick={() => copyToClipboard('#8B5CF6')}
                  className="p-1 hover:bg-slate-100 rounded"
                >
                  <Copy className="w-4 h-4 text-slate-500" />
                </button>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-lg border-2 border-slate-200" style={{ backgroundColor: '#8B5CF6' }}></div>
                <div>
                  <p className="font-mono text-sm font-bold text-slate-900">#8B5CF6</p>
                  <p className="font-mono text-xs text-slate-600">RGB(139, 92, 246)</p>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-4 bg-blue-50 border border-blue-200 rounded-lg p-4">
            <p className="text-sm font-semibold text-blue-900 mb-2">Gradient Direction</p>
            <p className="text-sm text-blue-700">Linear gradient from top-left (0, 0) to bottom-right (1024, 1024)</p>
            <p className="text-xs text-blue-600 mt-2 font-mono">angle: 135° (or -45° from horizontal)</p>
          </div>
        </Card>

        {/* Healthcare Workers Elements */}
        <Card className="p-6 mb-6 bg-white border-slate-200 shadow-sm">
          <h2 className="text-xl font-bold text-slate-900 mb-4">👥 Healthcare Workers Elements</h2>
          
          <div className="space-y-6">
            {/* Left Worker - Nurse */}
            <div className="border-2 border-slate-200 rounded-lg p-5">
              <h3 className="text-lg font-bold text-slate-900 mb-3">Left Worker - Nurse</h3>
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <p className="text-sm font-semibold text-slate-700 mb-2">Position</p>
                  <p className="font-mono text-sm text-slate-900">Center X: 312px (512 - 200)</p>
                  <p className="font-mono text-sm text-slate-900">Center Y: 600px</p>
                </div>
                <div>
                  <p className="text-sm font-semibold text-slate-700 mb-2">Components</p>
                  <ul className="text-sm space-y-1">
                    <li className="text-slate-900">• Head: Circle, radius 50px, white</li>
                    <li className="text-slate-900">• Body: Rectangle 120×150px, white (95% opacity)</li>
                    <li className="text-slate-900">• Medical Cross: Blue (#3B82F6, #6366F1)</li>
                  </ul>
                </div>
              </div>
            </div>

            {/* Center Worker - Doctor */}
            <div className="border-2 border-blue-200 bg-blue-50 rounded-lg p-5">
              <h3 className="text-lg font-bold text-blue-900 mb-3">Center Worker - Doctor (Primary)</h3>
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <p className="text-sm font-semibold text-blue-800 mb-2">Position</p>
                  <p className="font-mono text-sm text-blue-900">Center X: 512px</p>
                  <p className="font-mono text-sm text-blue-900">Center Y: 560px (elevated 40px)</p>
                </div>
                <div>
                  <p className="text-sm font-semibold text-blue-800 mb-2">Components</p>
                  <ul className="text-sm space-y-1">
                    <li className="text-blue-900">• Head: Circle, radius 55px, white</li>
                    <li className="text-blue-900">• Body: Rectangle 140×195px, white (100%)</li>
                    <li className="text-blue-900">• Stethoscope: Emerald (#10B981), 90% opacity</li>
                  </ul>
                </div>
              </div>
              <div className="mt-3 bg-white rounded p-3">
                <p className="text-xs text-blue-700"><strong>Note:</strong> Taller and centered - represents leadership/primary role</p>
              </div>
            </div>

            {/* Right Worker - Healthcare Staff */}
            <div className="border-2 border-slate-200 rounded-lg p-5">
              <h3 className="text-lg font-bold text-slate-900 mb-3">Right Worker - Healthcare Staff</h3>
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <p className="text-sm font-semibold text-slate-700 mb-2">Position</p>
                  <p className="font-mono text-sm text-slate-900">Center X: 712px (512 + 200)</p>
                  <p className="font-mono text-sm text-slate-900">Center Y: 600px</p>
                </div>
                <div>
                  <p className="text-sm font-semibold text-slate-700 mb-2">Components</p>
                  <ul className="text-sm space-y-1">
                    <li className="text-slate-900">• Head: Circle, radius 50px, white</li>
                    <li className="text-slate-900">• Body: Rectangle 120×150px, white (95% opacity)</li>
                    <li className="text-slate-900">• Clipboard: Amber (#F59E0B, #FBBF24)</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </Card>

        {/* Accent Colors */}
        <Card className="p-6 mb-6 bg-white border-slate-200 shadow-sm">
          <h2 className="text-xl font-bold text-slate-900 mb-4">🎯 Accent Colors (Medical Symbols)</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Medical Cross - Blue/Indigo */}
            <div className="border-2 border-slate-200 p-4 rounded-lg">
              <p className="text-sm font-semibold text-slate-700 mb-3">Medical Cross</p>
              <div className="space-y-2 mb-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded border-2 border-slate-200" style={{ backgroundColor: '#3B82F6' }}></div>
                  <div>
                    <p className="font-mono text-sm font-bold">#3B82F6</p>
                    <p className="text-xs text-slate-600">Vertical bar</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded border-2 border-slate-200" style={{ backgroundColor: '#6366F1' }}></div>
                  <div>
                    <p className="font-mono text-sm font-bold">#6366F1</p>
                    <p className="text-xs text-slate-600">Horizontal bar</p>
                  </div>
                </div>
              </div>
              <p className="text-xs text-slate-500">Left worker (Nurse)</p>
            </div>

            {/* Stethoscope - Emerald */}
            <div className="border-2 border-slate-200 p-4 rounded-lg">
              <p className="text-sm font-semibold text-slate-700 mb-3">Stethoscope</p>
              <div className="flex items-center gap-3 mb-3">
                <div className="w-10 h-10 rounded border-2 border-slate-200" style={{ backgroundColor: '#10B981' }}></div>
                <div>
                  <p className="font-mono text-sm font-bold">#10B981</p>
                  <p className="text-xs text-slate-600">RGB(16, 185, 129)</p>
                </div>
              </div>
              <p className="text-xs text-slate-500 mb-2">Center worker (Doctor)</p>
              <p className="text-xs text-slate-600">Opacity: 90%</p>
            </div>

            {/* Clipboard - Amber */}
            <div className="border-2 border-slate-200 p-4 rounded-lg">
              <p className="text-sm font-semibold text-slate-700 mb-3">Clipboard</p>
              <div className="space-y-2 mb-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded border-2 border-slate-200" style={{ backgroundColor: '#F59E0B' }}></div>
                  <div>
                    <p className="font-mono text-sm font-bold">#F59E0B</p>
                    <p className="text-xs text-slate-600">Main body</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded border-2 border-slate-200" style={{ backgroundColor: '#FBBF24' }}></div>
                  <div>
                    <p className="font-mono text-sm font-bold">#FBBF24</p>
                    <p className="text-xs text-slate-600">Clip</p>
                  </div>
                </div>
              </div>
              <p className="text-xs text-slate-500">Right worker (Healthcare Staff)</p>
            </div>
          </div>
        </Card>

        {/* Decorative Elements */}
        <Card className="p-6 mb-6 bg-white border-slate-200 shadow-sm">
          <h2 className="text-xl font-bold text-slate-900 mb-4">✨ Decorative Elements</h2>
          
          <div className="grid md:grid-cols-2 gap-4 mb-4">
            <div className="border-2 border-slate-200 p-4 rounded-lg">
              <p className="text-sm font-semibold text-slate-700 mb-2">Top-Right Circle</p>
              <ul className="text-sm space-y-1 text-slate-900">
                <li>• Position: (850, 200)</li>
                <li>• Radius: 180px</li>
                <li>• Color: White</li>
                <li>• Opacity: 10%</li>
              </ul>
            </div>

            <div className="border-2 border-slate-200 p-4 rounded-lg">
              <p className="text-sm font-semibold text-slate-700 mb-2">Bottom-Left Circle</p>
              <ul className="text-sm space-y-1 text-slate-900">
                <li>• Position: (180, 850)</li>
                <li>• Radius: 150px</li>
                <li>• Color: White</li>
                <li>• Opacity: 10%</li>
              </ul>
            </div>
          </div>

          <div className="border-2 border-blue-200 bg-blue-50 p-4 rounded-lg">
            <p className="text-sm font-semibold text-blue-900 mb-2">Shine Effect (Top)</p>
            <ul className="text-sm space-y-1 text-blue-800">
              <li>• Shape: Ellipse</li>
              <li>• Position: Center (512, 280)</li>
              <li>• Size: 350px × 180px (horizontal ellipse)</li>
              <li>• Color: White</li>
              <li>• Opacity: 12%</li>
              <li>• Purpose: Adds depth and lighting from above</li>
            </ul>
          </div>
        </Card>

        {/* iOS Icon Sizes */}
        <Card className="p-6 mb-6 bg-white border-slate-200 shadow-sm">
          <h2 className="text-xl font-bold text-slate-900 mb-4">📱 iOS Icon Sizes Required</h2>
          <p className="text-sm text-slate-600 mb-4">Export your design at these specific sizes for iOS app submission:</p>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <div className="bg-slate-50 p-3 rounded text-center">
              <p className="font-bold text-slate-900">20x20</p>
              <p className="text-xs text-slate-600">@2x: 40×40</p>
              <p className="text-xs text-slate-600">@3x: 60×60</p>
            </div>
            <div className="bg-slate-50 p-3 rounded text-center">
              <p className="font-bold text-slate-900">29x29</p>
              <p className="text-xs text-slate-600">@2x: 58×58</p>
              <p className="text-xs text-slate-600">@3x: 87×87</p>
            </div>
            <div className="bg-slate-50 p-3 rounded text-center">
              <p className="font-bold text-slate-900">40x40</p>
              <p className="text-xs text-slate-600">@2x: 80×80</p>
              <p className="text-xs text-slate-600">@3x: 120×120</p>
            </div>
            <div className="bg-slate-50 p-3 rounded text-center">
              <p className="font-bold text-slate-900">60x60</p>
              <p className="text-xs text-slate-600">@2x: 120×120</p>
              <p className="text-xs text-slate-600">@3x: 180×180</p>
            </div>
            <div className="bg-slate-50 p-3 rounded text-center">
              <p className="font-bold text-slate-900">76x76</p>
              <p className="text-xs text-slate-600">@2x: 152×152</p>
              <p className="text-xs text-slate-600">iPad</p>
            </div>
            <div className="bg-slate-50 p-3 rounded text-center">
              <p className="font-bold text-slate-900">83.5x83.5</p>
              <p className="text-xs text-slate-600">@2x: 167×167</p>
              <p className="text-xs text-slate-600">iPad Pro</p>
            </div>
            <div className="bg-blue-100 border-2 border-blue-400 p-3 rounded text-center">
              <p className="font-bold text-blue-900">1024x1024</p>
              <p className="text-xs text-blue-700">App Store</p>
              <p className="text-xs text-blue-700">Required</p>
            </div>
          </div>

          <div className="mt-4 bg-amber-50 border border-amber-200 rounded-lg p-4">
            <p className="text-sm font-semibold text-amber-900 mb-1">⚠️ Important Notes</p>
            <ul className="text-sm text-amber-800 space-y-1">
              <li>• All icons must be PNG format</li>
              <li>• No transparency (use solid background gradient)</li>
              <li>• No alpha channels on exported files</li>
              <li>• App Store icon (1024×1024) must have NO rounded corners - iOS applies them automatically</li>
            </ul>
          </div>
        </Card>

        {/* Design Guidelines */}
        <Card className="p-6 bg-white border-slate-200 shadow-sm">
          <h2 className="text-xl font-bold text-slate-900 mb-4">📋 Design Implementation Guidelines</h2>
          
          <div className="space-y-4">
            <div className="border-l-4 border-blue-500 pl-4">
              <p className="font-semibold text-slate-900 mb-1">Spacing & Alignment</p>
              <p className="text-sm text-slate-700">Workers are positioned 200px apart horizontally. Center worker is elevated 40px to show hierarchy and create visual interest.</p>
            </div>

            <div className="border-l-4 border-emerald-500 pl-4">
              <p className="font-semibold text-slate-900 mb-1">Visual Hierarchy</p>
              <p className="text-sm text-slate-700">The center doctor is larger (55px head vs 50px) and positioned higher to emphasize leadership while maintaining team balance.</p>
            </div>

            <div className="border-l-4 border-purple-500 pl-4">
              <p className="font-semibold text-slate-900 mb-1">Color Meaning</p>
              <p className="text-sm text-slate-700">Blue gradient conveys trust and professionalism. Green stethoscope = health/medical. Amber clipboard = organization/administrative tasks.</p>
            </div>

            <div className="border-l-4 border-amber-500 pl-4">
              <p className="font-semibold text-slate-900 mb-1">Opacity Strategy</p>
              <p className="text-sm text-slate-700">White silhouettes use 95-100% opacity for figures, with decorative elements at 10-12% to add depth without distraction.</p>
            </div>

            <div className="border-l-4 border-pink-500 pl-4">
              <p className="font-semibold text-slate-900 mb-1">Border Radius</p>
              <p className="text-sm text-slate-700">Small elements (5px) for medical symbols create clean, precise look. Main icon uses 226px (22%) per iOS Human Interface Guidelines.</p>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
