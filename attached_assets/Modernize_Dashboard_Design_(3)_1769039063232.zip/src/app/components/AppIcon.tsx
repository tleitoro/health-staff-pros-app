import { Card } from '@/app/components/ui/card';

export function AppIcon() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 flex items-center justify-center p-8">
      <div className="max-w-4xl w-full">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-slate-900 mb-3">
            Final Icon Design - Two Person Healthcare Staffing
          </h1>
          <p className="text-lg text-slate-600">
            Healthcare Professional + Worker = Staffing
          </p>
        </div>

        {/* Main Final Icon Display */}
        <div className="mb-8">
          <Card className="p-8 bg-white border-2 border-purple-500 shadow-2xl">
            <div className="absolute top-4 right-4">
              <span className="bg-purple-500 text-white text-xs font-bold px-3 py-1 rounded-full">FINAL DESIGN</span>
            </div>
            <h3 className="text-center font-bold text-slate-900 mb-6 text-xl">Healthcare Worker + Staff Member</h3>
            <div className="flex justify-center mb-6">
              <svg
                width="320"
                height="320"
                viewBox="0 0 1024 1024"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
                className="drop-shadow-2xl"
              >
                {/* Background with gradient */}
                <rect width="1024" height="1024" rx="226" fill="url(#gradFinal)" />
                
                <defs>
                  <linearGradient id="gradFinal" x1="0" y1="0" x2="1024" y2="1024" gradientUnits="userSpaceOnUse">
                    <stop offset="0%" stopColor="#8B5CF6" />
                    <stop offset="50%" stopColor="#7C3AED" />
                    <stop offset="100%" stopColor="#6D28D9" />
                  </linearGradient>
                </defs>

                {/* Decorative circles - subtle */}
                <circle cx="850" cy="200" r="200" fill="white" fillOpacity="0.08" />
                <circle cx="180" cy="850" r="180" fill="white" fillOpacity="0.08" />

                {/* Two people - Healthcare worker on left, plain person on right */}
                <g transform="translate(512, 540)">
                  
                  {/* Left - Healthcare Worker with Nurse Cap */}
                  <g transform="translate(-120, 0)">
                    {/* Head */}
                    <circle cx="0" cy="-130" r="90" fill="white" />
                    
                    {/* Nurse Cap */}
                    <path d="M -75 -135 L -75 -155 L 75 -155 L 75 -135 Z" fill="white" />
                    <ellipse cx="0" cy="-160" rx="70" ry="20" fill="white" />
                    
                    {/* Medical Cross on Cap */}
                    <rect x="-8" y="-175" width="16" height="28" fill="#8B5CF6" />
                    <rect x="-14" y="-167" width="28" height="12" fill="#8B5CF6" />
                    
                    {/* Body */}
                    <path d="M -105 -40 L -105 220 L 105 220 L 105 -40 Z" fill="white" />
                    
                    {/* Medical Cross on chest - larger */}
                    <rect x="-18" y="30" width="36" height="90" rx="8" fill="#8B5CF6" opacity="0.3" />
                    <rect x="-40" y="58" width="80" height="34" rx="8" fill="#7C3AED" opacity="0.3" />
                  </g>

                  {/* Right - Plain Staff Member (slightly smaller, no details) */}
                  <g transform="translate(120, 20)">
                    {/* Head */}
                    <circle cx="0" cy="-120" r="85" fill="white" fillOpacity="0.95" />
                    
                    {/* Body */}
                    <path d="M -100 -35 L -100 200 L 100 200 L 100 -35 Z" fill="white" fillOpacity="0.95" />
                  </g>
                  
                </g>

                {/* Shine effect */}
                <ellipse cx="512" cy="250" rx="400" ry="200" fill="white" fillOpacity="0.12" />
              </svg>
            </div>
            <p className="text-center text-slate-600 font-medium">
              Perfect balance: Healthcare identity (nurse cap + medical cross) + Staffing concept (two people)
            </p>
          </Card>
        </div>

        {/* Design Breakdown */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          {/* Left Person Details */}
          <Card className="p-6 bg-gradient-to-br from-purple-50 to-indigo-50 border-purple-200">
            <h3 className="text-lg font-bold text-purple-900 mb-4">👨‍⚕️ Left: Healthcare Worker</h3>
            <ul className="space-y-2 text-sm text-purple-800">
              <li className="flex items-start gap-2">
                <span className="text-purple-500 font-bold">•</span>
                <span><strong>Nurse Cap:</strong> Instantly recognizable healthcare symbol</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-purple-500 font-bold">•</span>
                <span><strong>Medical Cross on Cap:</strong> Purple (#8B5CF6) - reinforces medical context</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-purple-500 font-bold">•</span>
                <span><strong>Cross on Chest:</strong> Subtle transparency (30%) for depth</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-purple-500 font-bold">•</span>
                <span><strong>Size:</strong> Slightly larger - represents the healthcare industry</span>
              </li>
            </ul>
          </Card>

          {/* Right Person Details */}
          <Card className="p-6 bg-gradient-to-br from-slate-50 to-blue-50 border-slate-200">
            <h3 className="text-lg font-bold text-slate-900 mb-4">👤 Right: Staff Member</h3>
            <ul className="space-y-2 text-sm text-slate-700">
              <li className="flex items-start gap-2">
                <span className="text-slate-500 font-bold">•</span>
                <span><strong>Plain Silhouette:</strong> No medical symbols - represents general workforce</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-slate-500 font-bold">•</span>
                <span><strong>95% Opacity:</strong> Slightly subdued to let healthcare worker lead</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-slate-500 font-bold">•</span>
                <span><strong>Elevated 20px:</strong> Creates visual variety and balance</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-slate-500 font-bold">•</span>
                <span><strong>Together:</strong> Two people = staffing/workforce concept</span>
              </li>
            </ul>
          </Card>
        </div>

        {/* Color Specifications */}
        <Card className="p-6 mb-6 bg-white border-slate-200 shadow-sm">
          <h2 className="text-xl font-bold text-slate-900 mb-4">🎨 Purple Gradient Specification</h2>
          
          <div className="mb-4">
            <div className="h-32 rounded-lg mb-3" style={{
              background: 'linear-gradient(135deg, #8B5CF6 0%, #7C3AED 50%, #6D28D9 100%)'
            }}></div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="border-2 border-purple-200 p-4 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <p className="text-sm font-semibold text-slate-700">Start (0%)</p>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-lg border-2 border-slate-200" style={{ backgroundColor: '#8B5CF6' }}></div>
                <div>
                  <p className="font-mono text-sm font-bold text-slate-900">#8B5CF6</p>
                  <p className="font-mono text-xs text-slate-600">RGB(139, 92, 246)</p>
                </div>
              </div>
            </div>

            <div className="border-2 border-purple-200 p-4 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <p className="text-sm font-semibold text-slate-700">Middle (50%)</p>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-lg border-2 border-slate-200" style={{ backgroundColor: '#7C3AED' }}></div>
                <div>
                  <p className="font-mono text-sm font-bold text-slate-900">#7C3AED</p>
                  <p className="font-mono text-xs text-slate-600">RGB(124, 58, 237)</p>
                </div>
              </div>
            </div>

            <div className="border-2 border-purple-200 p-4 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <p className="text-sm font-semibold text-slate-700">End (100%)</p>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-lg border-2 border-slate-200" style={{ backgroundColor: '#6D28D9' }}></div>
                <div>
                  <p className="font-mono text-sm font-bold text-slate-900">#6D28D9</p>
                  <p className="font-mono text-xs text-slate-600">RGB(109, 40, 217)</p>
                </div>
              </div>
            </div>
          </div>
        </Card>

        {/* Why This Works */}
        <Card className="p-6 bg-gradient-to-r from-purple-50 to-blue-50 border-2 border-purple-200">
          <h2 className="text-xl font-bold text-slate-900 mb-4">✨ Why This Design Works</h2>
          <div className="grid md:grid-cols-3 gap-6">
            <div>
              <h3 className="font-bold text-purple-900 mb-3">🏥 Healthcare Identity</h3>
              <ul className="space-y-1 text-sm text-slate-700">
                <li>✓ Nurse cap = instant medical recognition</li>
                <li>✓ Medical cross reinforces healthcare</li>
                <li>✓ Clear industry context</li>
              </ul>
            </div>
            <div>
              <h3 className="font-bold text-blue-900 mb-3">👥 Staffing Concept</h3>
              <ul className="space-y-1 text-sm text-slate-700">
                <li>✓ Two people = workforce/staffing</li>
                <li>✓ Healthcare pro + general worker</li>
                <li>✓ Clear "connecting talent" message</li>
              </ul>
            </div>
            <div>
              <h3 className="font-bold text-indigo-900 mb-3">⚡ Instant Recognition</h3>
              <ul className="space-y-1 text-sm text-slate-700">
                <li>✓ Bold, simple shapes</li>
                <li>✓ Works at all sizes (40px-1024px)</li>
                <li>✓ Memorable silhouette</li>
              </ul>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}